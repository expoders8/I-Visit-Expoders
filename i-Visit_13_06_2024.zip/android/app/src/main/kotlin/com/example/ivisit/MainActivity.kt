package com.tnetic.ivisit

import android.os.Bundle
import android.util.Log
import androidx.annotation.NonNull
import com.tnetic.ivisit.PcProxAPI
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "pcprox_api"

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "scan" -> {
                    try {
                        val api = PcProxAPI() // Initialize your API
                        val scanResult = api.scan() // Or whatever method you need to call
                        result.success(scanResult)
                    } catch (e: Exception) {
                        result.error("UNAVAILABLE", "Scanning failed", e.message)
                    }
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }
}
